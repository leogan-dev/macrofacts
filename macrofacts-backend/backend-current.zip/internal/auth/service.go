package auth

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strings"
	"time"

	"github.com/leogan-dev/macrofacts/macrofacts-backend/internal/ratelimit"
	"golang.org/x/crypto/bcrypt"
)

type Service struct {
	repo      *Repo
	jwtSecret []byte
	rl        *ratelimit.Limiter
}

func NewService(repo *Repo, jwtSecret string, rl *ratelimit.Limiter) *Service {
	return &Service{
		repo:      repo,
		jwtSecret: []byte(jwtSecret),
		rl:        rl,
	}
}

func canonicalUsername(u string) string {
	return strings.ToUpper(strings.TrimSpace(u))
}

func (s *Service) Register(username, password string) error {
	username = canonicalUsername(username)
	if len(username) < 3 || len(username) > 32 {
		return errors.New("username must be 3-32 chars")
	}
	if len(password) < 8 || len(password) > 128 {
		return errors.New("password must be 8-128 chars")
	}

	if s.rl != nil {
		if !s.rl.Allow("register:" + username) {
			return errors.New("too many attempts, try again later")
		}
	}

	// Privacy-first: store a stable hash of the username (not email)
	uh := sha256.Sum256([]byte(username))
	usernameHash := hex.EncodeToString(uh[:])

	pwHash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return errors.New("failed to hash password")
	}

	userID, err := s.repo.CreateUser(username, usernameHash, string(pwHash))
	if err != nil {
		return err
	}

	// Create default settings immediately.
	_ = s.repo.UpsertSettings(userID, UpdateSettingsRequest{
		Timezone:     ptrStr("UTC"),
		CalorieGoal:  ptrInt(2000),
		ProteinGoalG: ptrInt(150),
		CarbsGoalG:   ptrInt(200),
		FatGoalG:     ptrInt(70),
	})

	return nil
}

func (s *Service) Login(username, password string) (string, error) {
	username = canonicalUsername(username)

	if s.rl != nil {
		if !s.rl.Allow("login:" + username) {
			return "", errors.New("too many attempts, try again later")
		}
	}

	u, err := s.repo.GetUserByUsername(username)
	if err != nil {
		return "", errors.New("invalid credentials")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(u.PasswordHash), []byte(password)); err != nil {
		return "", errors.New("invalid credentials")
	}

	return IssueToken(s.jwtSecret, u.ID, u.Username, time.Now().Add(7*24*time.Hour))
}

func (s *Service) GetSettings(userID string) (MeSettingsResponse, error) {
	// Lazy-create if missing, so Today never bricks.
	settings, err := s.repo.GetSettings(userID)
	if err == nil {
		return settings, nil
	}

	_ = s.repo.UpsertSettings(userID, UpdateSettingsRequest{
		Timezone:     ptrStr("UTC"),
		CalorieGoal:  ptrInt(2000),
		ProteinGoalG: ptrInt(150),
		CarbsGoalG:   ptrInt(200),
		FatGoalG:     ptrInt(70),
	})

	return s.repo.GetSettings(userID)
}

func (s *Service) UpdateSettings(userID string, req UpdateSettingsRequest) (MeSettingsResponse, error) {
	// Ensure exists, then update.
	_, _ = s.GetSettings(userID)

	if err := s.repo.UpsertSettings(userID, req); err != nil {
		return MeSettingsResponse{}, err
	}
	return s.repo.GetSettings(userID)
}

// --- helpers ---

func ptrStr(v string) *string { return &v }
func ptrInt(v int) *int       { return &v }

// Silence unused import in some setups (context used by repo in older versions)
var _ = context.Background
