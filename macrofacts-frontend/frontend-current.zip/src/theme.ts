export type Theme = "light" | "dark";
const KEY = "macrofacts_theme";

function getSystemTheme(): Theme {
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light";
}

export function getInitialTheme(): Theme {
    const saved = localStorage.getItem(KEY);
    if (saved === "light" || saved === "dark") return saved;
    return getSystemTheme();
}

export function applyTheme(theme: Theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem(KEY, theme);
}

export function toggleTheme(current: Theme): Theme {
    const next: Theme = current === "dark" ? "light" : "dark";
    applyTheme(next);
    return next;
}
