import { createRoot } from "react-dom/client";
import App from "./App";

import "./styles/theme.css";
import "./styles/ui.css";

import { applyTheme, getInitialTheme } from "./theme";
applyTheme(getInitialTheme());

const rootEl = document.getElementById("root");
if (!rootEl) throw new Error("Missing #root");

createRoot(rootEl).render(
    <App />
);
